//FATEC BEBEDOURO 2026 - 4° SEMESTRE BIG DATA NO AGRONEGÓCIO
//ALUNO: VICTOR DOS SANTOS QUEIROZ | RA: 2801262423001
//ALUNO: IGOR IFRAN | RA: 280126423002

#include <iostream> // Biblioteca para entrada e saída de dados
#include <string> // Biblioteca para manipulação de strings
#include <limits> // Biblioteca para limpar o buffer de entrada
#include "../include/menu.h"

using namespace std;

//====================
// LIMPAR BUFFER
//====================

//Limpa o buffer de entrada para evitar erro nas próximas leituras
void limparBufferEntrada() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

//====================
// LER INTEIRO
//====================

//Lê um número inteiro e trata entrada inválida
bool lerInteiro(string mensagem, int &valor) {
    cout << mensagem;
    cin >> valor;

    if (cin.fail()) {
        cout << "Erro: Digite um numero inteiro valido." << endl;
        limparBufferEntrada();
        return false;
    }

    limparBufferEntrada();
    return true;
}

//====================
// LER FLOAT
//====================

//Lê um número decimal e trata entrada inválida
bool lerFloat(string mensagem, float &valor) {
    cout << mensagem;
    cin >> valor;

    if (cin.fail()) {
        cout << "Erro: Digite um numero valido." << endl;
        limparBufferEntrada();
        return false;
    }

    limparBufferEntrada();
    return true;
}

// ====================
// MENU ADMIN
// ====================

void menuAdmin(Produto* &head, Produto* &tail, Slot slots[]) {
    char opcao;
    do {
        cout << "\n========== MENU ADMIN ==========\n";
        cout << "1 - Cadastrar produto\n";
        cout << "2 - Ativar produto na maquina\n";
        cout << "3 - Desativar produto\n";
        cout << "4 - Alterar local de produto\n";
        cout << "5 - Listar produtos\n";
        cout << "6 - Listar slots ativos\n";
        cout << "7 - Ver locais disponiveis\n";
        cout << "8 - Cadastrar estoque teste\n";
        cout << "9 - Voltar\n";
        cout << "\nEscolha uma opcao: ";
        cin >> opcao;
        limparBufferEntrada();

        switch (opcao) {
            case '1': {
                string nome;
                float valor;
                int estoqueTotal;

                cout << "Digite o nome do produto: ";
                getline(cin, nome);

                if (!lerFloat("Digite o valor do produto: ", valor)) {
                    break;
                }

                if (!lerInteiro("Digite o estoque total do produto: ", estoqueTotal)) {
                    break;
                }

                if (cadastrarProduto(head, tail, nome, valor, estoqueTotal)) {
                    cout << "Produto cadastrado com sucesso!" << endl;
                }
                break;
            }
            case '2': {
                int id;
                int local;
                int quantidadeSlot;

                listarProdutos(head, tail);
                listarLocaisDisponiveis(slots);

                if (!lerInteiro("Digite o ID do produto: ", id)) {
                    break;
                }

                if (!lerInteiro("Digite o local na maquina: ", local)) {
                    break;
                }

                if (!lerInteiro("Digite a quantidade para carregar no local: ", quantidadeSlot)) {
                    break;
                }

                ativarProduto(head, tail, slots, id, local, quantidadeSlot);
                break;
            }
            case '3': {
                int local;
                int escolhaStatus;
                StatusProduto novoStatus = INATIVO;

                listarSlots(slots);

                if (!lerInteiro("Digite o local que deseja desativar: ", local)) {
                    break;
                }

                cout << "1 - Inativo\n";
                cout << "2 - Esgotado\n";
                cout << "3 - Manutencao\n";

                if (!lerInteiro("Escolha o novo status do produto: ", escolhaStatus)) {
                    break;
                }

                if (escolhaStatus == 2) {
                    novoStatus = ESGOTADO;
                } else if (escolhaStatus == 3) {
                    novoStatus = MANUTENCAO;
                }

                desativarProduto(head, tail, slots, local, novoStatus);
                break;
            }
            case '4': {
                int localAtual;
                int novoLocal;

                listarSlots(slots);
                listarLocaisDisponiveis(slots);

                if (!lerInteiro("Digite o local atual do produto: ", localAtual)) {
                    break;
                }

                if (!lerInteiro("Digite o novo local do produto: ", novoLocal)) {
                    break;
                }

                alterarLocalProduto(slots, localAtual, novoLocal);
                break;
            }
            case '5': {
                listarProdutos(head, tail);
                break;
            }
            case '6': {
                listarSlots(slots);
                break;
            }
            case '7': {
                listarLocaisDisponiveis(slots);
                break;
            }
            case '8': {
                cadastrarEstoqueTeste(head, tail);
                break;
            }
            case '9': {
                cout << "Voltando ao menu principal..." << endl;
                break;
            }
            default: {
                cout << "Opcao invalida." << endl;
                break;
            }
        }
    } while (opcao != '9');
}
