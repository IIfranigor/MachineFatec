//FATEC BEBEDOURO 2026 - 4° SEMESTRE BIG DATA NO AGRONEGÓCIO
//ALUNO: VICTOR DOS SANTOS QUEIROZ | RA: 2801262423001
//ALUNO: IGOR IFRAN | RA: 280126423002

#include <iostream> // Biblioteca para entrada e saída de dados
#include "include/produto.h"
#include "include/menu.h"

using namespace std;

int main(){
    Produto* head;
    Produto* tail;
    Slot slots[50];
    char opcao;

    inicializarEstoqueProduto(head, tail);
    inicializarSlots(slots);

    cout << "Maquina de vendas de conveniencia" << endl;
    // Pressiona enter para acessar o menu de usuario padrao e digite 9 para acessar administrativo

    do {
        cout << "\nDigite 9 para acessar o menu administrativo ou 0 para sair: ";
        cin >> opcao;
        limparBufferEntrada();

        if (opcao == '9') {
            menuAdmin(head, tail, slots);
        } else if (opcao != '0') {
            cout << "Opcao invalida." << endl;
        }
    } while (opcao != '0');

    destruirLista(head, tail);

    return 0;
}
